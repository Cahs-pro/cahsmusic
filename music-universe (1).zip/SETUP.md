# Music Universe — Paddle VIP Quraşdırma Bələdçisi

## Fayl strukturu

```
cahsmusic/
├── index.html
├── manifest.json
├── sw.js
├── vercel.json
├── package.json
├── firebase-rules.json
├── SETUP.md
├── icon-192.png
├── icon-512.png
└── api/
    ├── dl.js                  ← MP3 link (mövcud)
    ├── paddle-checkout.js     ← ✨ Checkout session yaradır
    ├── paddle-webhook.js      ← ✨ Paddle → Firebase VIP sync
    └── admin-vip.js           ← ✨ Admin VIP idarəetmə
```

---

## Niyə Paddle?

- ✅ Azərbaycan merchant kimi dəstəklənir
- ✅ İstifadəçilər Visa / Mastercard / Google Pay / Apple Pay ilə ödəyir
- ✅ Payout dünya üzrə bank köçürməsi ilə
- ✅ Vergi, fraud, dispute — hamısını Paddle idarə edir (Merchant of Record)
- ✅ 5% + $0.50 komissiya — $2.99-dan ~$0.35 tutulur

---

## Addım 1 — Paddle hesabı

1. https://paddle.com → **Sign up** → **Seller** seç
2. Ölkə: **Azerbaijan** seç ✅
3. Bank hesabı: Azərbaycan bankı (Kapital, ABB, PASHA) → IBAN əlavə et
4. Şirkət məlumatları: Individual / Freelancer seçə bilərsən

---

## Addım 2 — Paddle Dashboard-da Product yarat

1. **Paddle Dashboard** → **Catalog** → **Products** → **New product**
2. Name: `Music Universe VIP`
3. **Prices** tabına keç → **Add price**
   - Amount: `$2.99`
   - Billing period: **Monthly**
   - **Save** → `price_XXXXXXXXXXXXXXX` ID-ni kopyala
   - Bu **PADDLE_PRICE_ID** olacaq

---

## Addım 3 — Paddle API Key

**Dashboard** → **Developer Tools** → **Authentication** → **Generate API key**
- Type: **Server-side** 
- Bu `PADDLE_API_KEY` olacaq (sandboxda: `test_...`, liveda: başqa format)

---

## Addım 4 — Webhook quraşdırması

**Dashboard** → **Developer Tools** → **Notifications** → **New destination**
- URL: `https://cahsmusic.vercel.app/api/paddle-webhook`
- Events seç:
  - ✅ `transaction.completed`
  - ✅ `subscription.activated`
  - ✅ `subscription.updated`
  - ✅ `subscription.canceled`
  - ✅ `subscription.past_due`
- **Save** → **Secret key** kopyala → Bu **PADDLE_WEBHOOK_SECRET** olacaq

---

## Addım 5 — Firebase Service Account

1. https://console.firebase.google.com → `lifecanvas12`
2. ⚙️ **Settings** → **Service accounts** → **Generate new private key**
3. Yüklənən JSON faylının məzmununu kopyala

---

## Addım 6 — Vercel Environment Variables

https://vercel.com → `cahsmusic` → **Settings** → **Environment Variables**

| Name | Value |
|---|---|
| `PADDLE_API_KEY` | Paddle Dashboard-dan aldığın API key |
| `PADDLE_PRICE_ID` | `price_XXXXXXXXXXXXXXX` |
| `PADDLE_WEBHOOK_SECRET` | Webhook secret key |
| `FIREBASE_SERVICE_ACCOUNT` | `{"type":"service_account",...}` tam JSON |
| `APP_URL` | `https://cahsmusic.vercel.app` |
| `RAPIDAPI_KEY` | (mövcud) |

---

## Addım 7 — Özünüzü Admin + VIP edin

**Firebase Console** → Realtime Database → `users/b11lSYWjuGe0Lu3xeNW3YJOMTuI3`

Əl ilə əlavə edin:
```json
{
  "vip": true,
  "vipSetByAdmin": true,
  "vipSince": 1700000000000
}
```

**VƏ YA deploy sonrası brauzer konsolunda:**
```javascript
const token = await firebase.auth().currentUser.getIdToken(true);
const res = await fetch('/api/admin-vip', {
  method: 'POST',
  headers: {'Content-Type':'application/json'},
  body: JSON.stringify({
    idToken: token,
    targetUid: 'b11lSYWjuGe0Lu3xeNW3YJOMTuI3',
    vip: true
  })
});
console.log(await res.json());
```

---

## Addım 8 — Firebase Database Rules

Firebase Console → Realtime Database → **Rules** tabı →
`firebase-rules.json` məzmununu yapışdır → **Publish**

---

## Addım 9 — Test etmə (Paddle Sandbox)

1. Paddle Dashboard-da **Sandbox mode** aktiv et
2. Vercel-də test API key-ləri əlavə et
3. Tətbiqdə VIP modalını aç → "VIP-ə Keç"
4. Paddle sandbox checkout açılır
5. Test kart: `4242 4242 4242 4242` / istənilən tarix / `100` CVC
6. Ödəniş → `/?vip=success` → Firebase poll → 👑 badge

---

## Addım 10 — Production-a keçid

1. Paddle Dashboard-da **Live mode**-a keç
2. Live API key-ləri Vercel env-ə əlavə et
3. Live webhook endpoint yarat (eyni URL)
4. Vercel redeploy et

---

## Ödəniş axını

```
İstifadəçi → "VIP-ə Keç"
    ↓
POST /api/paddle-checkout (Firebase token yoxlayır)
    ↓  
Paddle Checkout (paddle.com-da — Visa/MC/Google Pay/Apple Pay)
    ↓
Ödəniş uğurlu
    ↓
Paddle → POST /api/paddle-webhook (transaction.completed)
    ↓
Firebase: users/{uid}/vip = true
    ↓
/?vip=success → tətbiq poll edir → 👑 VIP badge
```

---

## Manual VIP vermə (admin-vip.js)

```javascript
// Brauzer konsolunda (admin hesabında giriş edilmiş halda)
const token = await firebase.auth().currentUser.getIdToken(true);

// VIP ver
await fetch('/api/admin-vip', {
  method:'POST', headers:{'Content-Type':'application/json'},
  body: JSON.stringify({ idToken:token, targetUid:'TARGET_UID', vip:true })
}).then(r=>r.json()).then(console.log);

// VIP al
await fetch('/api/admin-vip', {
  method:'POST', headers:{'Content-Type':'application/json'},
  body: JSON.stringify({ idToken:token, targetUid:'TARGET_UID', vip:false })
}).then(r=>r.json()).then(console.log);
```

---

## Qeydlər

- **Pulsuz:** 20 endirilmiş mahnı, 3 playlist
- **VIP:** Limitsiz + EQ + Crossfade + 👑 badge
- Admin UID `b11lSYWjuGe0Lu3xeNW3YJOMTuI3` kodda həmişə VIP sayılır
- Paddle komissiyası: 5% + $0.50 → $2.99-dan ~$0.35 tutulur → $2.64 sənə qalır
- Payout: Ayda 2 dəfə, Azərbaycan bankına IBAN vasitəsilə
